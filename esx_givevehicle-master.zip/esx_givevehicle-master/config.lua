Config = {}
Config.Locale = 'en'

Config.ReceiveMsg = true

-- Allow below identifier player to execute commands
Config.AuthorizedRanks = {
  'superadmin',
--  'admin'
}
